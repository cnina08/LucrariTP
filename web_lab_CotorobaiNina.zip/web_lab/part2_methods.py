# Laborator: funcții, metode și importuri pe web - Partea 2
# Student: <Cotorobai Nina>

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

print("=== PARTEA 2: Metode și atribute ===")

# Exercițiul 9. Elementele de bază ale răspunsului
print("\n--- Exercițiul 9 ---")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("status_code:", response.status_code, "-> Atribut")
print("ok:", response.ok, "-> Atribut")
print("url:", response.url, "-> Atribut")
print("encoding:", response.encoding, "-> Atribut")

# Exercițiul 10. Tratarea erorilor cu o metodă
print("\n--- Exercițiul 10 ---")
try:
    response.raise_for_status()
    print("Pagina principală s-a încărcat cu succes (fără erori HTTP).")
    
    # Cerere către o pagină care nu există
    bad_response = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    bad_response.raise_for_status()
except requests.HTTPError as e:
    print("Eroare HTTP prinsă cu succes:", e)

# Exercițiul 11. Toate antetele
print("\n--- Exercițiul 11 ---")
for header_name, header_val in response.headers.items():
    print(f"{header_name}: {header_val}")

# Exercițiul 12. Metode de dicționar
print("\n--- Exercițiul 12 ---")
server_val = response.headers.get("Server", "lipsește")
content_type_val = response.headers.get("Content-Type", "lipsește")
print("Antet Server:", server_val)
print("Antet Content-Type:", content_type_val)

# Încercare cu litere mici
lowercase_ct = response.headers.get("content-type", "lipsește")
print("Antet content-type (cu litere mici):", lowercase_ct)
# Observație: dicționarul de antete din requests este case-insensitive (nu ține cont de majuscule/minuscule).

# Exercițiul 13. Înlănțuirea metodelor de șir
print("\n--- Exercițiul 13 ---")
cyber_count = response.text.lower().count("cyber")
print("De câte ori apare cuvântul 'cyber':", cyber_count)
# De ce putem înlănțui .lower() și .count()?
# Răspuns: .lower() returnează un nou șir de caractere (string), iar șirurile în Python 
# au la rândul lor metoda .count(), permițând apelarea directă a uneia după cealaltă.

# Exercițiul 14. Găsirea titlului
print("\n--- Exercițiul 14 ---")
html_text = response.text
start_tag = "<title>"
end_tag = "</title>"
start_idx = html_text.find(start_tag)
if start_idx != -1:
    start_pos = start_idx + len(start_tag)
    end_pos = html_text.find(end_tag, start_pos)
    if end_pos != -1:
        title_text = html_text[start_pos:end_pos].strip()
        print("Titlul extras:", title_text)

# Exercițiul 15. Numărarea liniilor
print("\n--- Exercițiul 15 ---")
lines = response.text.splitlines()
print("Număr total de linii:", len(lines))
longest_line = max(lines, key=len)
print("Lungimea celei mai lungi linii:", len(longest_line))

# Exercițiul 16. Verificarea HTTPS
print("\n--- Exercițiul 16 ---")
if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")

# Exercițiul 17. Urmărirea redirecționărilor
print("\n--- Exercițiul 17 ---")
try:
    # Folosim HTTP simplu către cybercor.org pentru a vedea redirecționarea spre HTTPS
    redirect_res = requests.get("http://cybercor.org", timeout=TIMEOUT)
    print("Istoric redirecționări:")
    for history_item in redirect_res.history:
        print(f"  Cod status: {history_item.status_code}, URL: {history_item.url}")
    print("URL final:", redirect_res.url)
except Exception as e:
    print("Eroare la redirecționare:", e)

# Exercițiul 18. HEAD versus GET
print("\n--- Exercițiul 18 ---")
head_res = requests.head(BASE_URL, timeout=TIMEOUT)
get_res = requests.get(BASE_URL, timeout=TIMEOUT)
print("Lungime conținut HEAD (len(head_res.content)):", len(head_res.content))
print("Lungime conținut GET (len(get_res.content)):", len(get_res.content))
# Diferența: Metoda HEAD cere doar antetele de la server, fără corpul paginii (body), 
# motiv pentru care lungimea conținutului returnat este 0 sau goală, pe când GET aduce și corpul complet.

# Exercițiul 19. Cookie-uri
print("\n--- Exercițiul 19 ---")
if len(response.cookies) == 0:
    print("Niciun cookie setat")
else:
    for cookie in response.cookies:
        print(f"Cookie: {cookie.name}, Secure: {cookie.secure}")

# Exercițiul 20. Sesiuni
print("\n--- Exercițiul 20 ---")
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Nina"})
echo_res = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print("Răspuns de la ECHO_URL (confirmare User-Agent):")
print(echo_res.text)
# Programul principal main.py
import sys
import argparse
import json
import csv
from datetime import datetime
import webtools

def main():
    parser = argparse.ArgumentParser(description="Generează raportul de securitate și structură pentru un site web.")
    parser.add_argument("url", nargs="?", default="https://cybercor.org", help="URL-ul țintă pentru analiză")
    args = parser.parse_args()
    
    target_url = args.url
    parsed_netloc = webtools.urllib.parse.urlparse(target_url).netloc
    
    print(f"=== Raport site: {target_url} ===")
    
    # Colectare date proiect final (Exercițiul 50)
    data = webtools.site_report(target_url)
    
    print(f"Cod de stare:      {data['status_code']}")
    print(f"Titlu:             {data['title']}")
    print(f"Adresă IP:         {data['ip_address']}")
    
    redirection_str = " -> ".join(data['redirects'] + [target_url]) if data['redirects'] else "Fără redirecționare"
    print(f"Redirecționări:    {redirection_str}")
    print(f"Scor securitate:   {data['security_score']}")
    print(f"Certificat:        {data['cert_days_left']} de zile rămase")
    print(f"Legături:          {data['internal_links']} interne, {data['external_links']} externe")
    print(f"Căi interzise:     {', '.join(data['disallowed_paths']) if data['disallowed_paths'] else 'Niciuna'}")
    
    # Salvare în report.json (Exercițiul 50)
    with open("report.json", "w", encoding="utf-8") as f_json:
        json.dump(data, f_json, indent=2)
    print("Salvat în report.json")
    
    # Salvare în report.csv (Exercițiul 49 - verificare căi de bază)
    paths_to_check = ["/", "/robots.txt", "/sitemap.xml"]
    path_statuses = webtools.check_paths(target_url, paths_to_check)
    checked_timestamp = datetime.now().isoformat()
    
    with open("report.csv", "w", newline="", encoding="utf-8") as f_csv:
        writer = csv.writer(f_csv)
        writer.writerow(["path", "status", "checked_at"])
        for p, st in path_statuses.items():
            writer.writerow([p, st, checked_timestamp])
    print("Salvat în report.csv")

if __name__ == "__main__":
    main()
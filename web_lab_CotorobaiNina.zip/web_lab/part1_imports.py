# Laborator: functii, metode si importuri pe web
#Student: <Cotorobai Nina>

import urllib.request
import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiul 1. Primul import
print("--- Exercitiul 1 ---")
print("Versiune requests:", requests.__version__)
# De ce requests a avut nevoie de pip install, iar urllib nu?
# Răspuns: requests este o bibliotecă externă (nu face parte din nucleul Python), 
# motiv pentru care trebuie instalată separat prin pip. În schimb, urllib face parte 
# din biblioteca standard Python (standard library), fiind instalată automat odată cu Python.

# Exercițiul 2. Două stiluri de import
print("\n--- Exercitiul 2 ---")
# Stil 1: import complet
response1 = requests.get(BASE_URL, timeout=TIMEOUT)
print("Stil 1 (requests.get) status:", response1.status_code)

# Stil 2: import specific (from ... import ...)
from requests import get
response2 = get(BASE_URL, timeout=TIMEOUT)
print("Stil 2 (from requests import get) status:", response2.status_code)
# Avantaj stil 1: Numele modulului este vizibil (requests.get), deci codul este mai clar 
# și eviți coliziunile de nume.
# Avantaj stil 2: Scrii cod mai scurt, apelând funcția direct (get) fără să mai repeți prefixul.

# Exercițiul 3. Alias-uri
print("\n--- Exercitiul 3 ---")
import requests as rq
response3 = rq.get(BASE_URL, timeout=TIMEOUT)
print("Alias rq status:", response3.status_code)
# Un alias face codul mai scurt sau mai ușor de citit când numele bibliotecii este lung 
# (de exemplu, pandas ca pd), dar poate face codul mai greu de citit dacă folosești 
# prescurtări necunoscute sau neintuitive pentru alții.

# Exercițiul 4. Doar biblioteca standard
print("\n--- Exercitiul 4 ---")
# Creăm un obiect de tip Request în care adăugăm un antet User-Agent ca să nu luăm eroare 403
req = urllib.request.Request(
    BASE_URL, 
    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
)
with urllib.request.urlopen(req) as u_response:
    # Atributul .status arată codul de stare (echivalentul lui status_code)
    print("Urllib status:", u_response.status)
    body_bytes = u_response.read(200)  # citește primii 200 octeți
    print("Primele 200 caractere:", body_bytes.decode("utf-8"))

# Exercițiul 5. Priviți în interiorul unui modul
print("\n--- Exercitiul 5 ---")
print(dir(requests))
# Trei elemente alese din dir(requests):
# - requests.get: este o funcție (metodă de trimitere cereri HTTP GET)
# - requests.Session: este o clasă (folosită pentru a menține starea/cookie-urile între cereri)
# - requests.exceptions: este un modul (conține excepțiile HTTP)

# Exercițiul 6
help(requests.get)
response_timeout = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cerere cu timeout reușită, status:", response_timeout.status_code)

# Exercițiul 7. Cronometrarea unei cereri
print("\n--- Exercitiul 7 ---")
start_time = time.perf_counter()
res_timed = requests.get(BASE_URL, timeout=TIMEOUT)
end_time = time.perf_counter()
print("Timp măsurat manual (secunde):", end_time - start_time)
print("Timp raportat de response.elapsed:", res_timed.elapsed.total_seconds())

# Exercițiul 8. Când un import eșuează
print("\n--- Exercitiul 8 ---")
try:
    import bs4
    print("Modulul bs4 este instalat.")
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")


# Laborator: funcții, metode și importuri pe web - Partea 3
# Student: <Cotorobai Nina>

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

print("=== PARTEA 3: Scrierea propriilor funcții ===")

# Exercițiul 21. Prima funcție
def fetch(url):
    """Trimite o cerere GET către url și returnează obiectul răspuns."""
    return requests.get(url, timeout=TIMEOUT)

print("\n--- Exercițiul 21 ---")
resp_ex21 = fetch(BASE_URL)
print("Status pagină principală (prin fetch):", resp_ex21.status_code)


# Exercițiul 22. Returnarea unei singure valori
def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

print("\n--- Exercițiul 22 ---")
paths = ["/", "/robots.txt", "/sitemap.xml"]
for p in paths:
    full_url = BASE_URL + p
    status = get_status(full_url)
    print(f"URL: {full_url} -> Status: {status}")
    time.sleep(1)  # Pauză între cereri conform regulilor de laborator

# Exercițiul 23. Parametri impliciți
def fetch_with_timeout(url, timeout=10):
    """Trimite o cerere GET folosind un timeout configurabil."""
    return requests.get(url, timeout=timeout)

print("\n--- Exercițiul 23 ---")
res_default = fetch_with_timeout(BASE_URL)  # Folosește valoarea implicită (10)
res_custom = fetch_with_timeout(BASE_URL, timeout=3)
print("Apel cu timeout implicit (10s) - Status:", res_default.status_code)
print("Apel cu timeout personalizat (3s) - Status:", res_custom.status_code)

# Exercițiul 24. O singură sarcină pe funcție
def get_title(html):
    """Primește un șir HTML și returnează titlul paginii curățat."""
    start_tag = "<title>"
    end_tag = "</title>"
    start_idx = html.find(start_tag)
    if start_idx != -1:
        start_pos = start_idx + len(start_tag)
        end_pos = html.find(end_tag, start_pos)
        if end_pos != -1:
            return html[start_pos:end_pos].strip()
    return "Fără titlu"

print("\n--- Exercițiul 24 ---")
pag_title = get_title(resp_ex21.text)
print("Titlul extras prin funcție:", pag_title)

# Exercițiul 25. Docstring-uri
print("\n--- Exercițiul 25 ---")
print("Docstring-ul funcției get_title:")
print(get_title.__doc__)

# Exercițiul 27. Fără opriri neașteptate
def page_exists(url):
    """Verifică dacă un URL există, returnând True sau False fără a genera erori fatale."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.ok
    except requests.RequestException:
        return False

print("\n--- Exercițiul 27 ---")
print("Există BASE_URL?", page_exists(BASE_URL))
print("Există un domeniu invalid?", page_exists("https://this-domain-does-not-exist.invalid"))

# Exercițiul 28. Returnarea unui dicționar
def check_paths(base, paths_list):
    """Verifică o listă de căi raportate la o adresă de bază și returnează un dicționar {path: status_code}."""
    results = {}
    for path in paths_list:
        full_url = base + path
        try:
            r = requests.get(full_url, timeout=TIMEOUT)
            results[path] = r.status_code
        except requests.RequestException:
            results[path] = None
        time.sleep(1)
    return results

print("\n--- Exercițiul 28 ---")
path_results = check_paths(BASE_URL, ["/", "/robots.txt", "/paginainexistenta"])
print("Rezultate verificare căi:", path_results)


# Exercițiul 29. Argumente cu nume
def get_header(url, name, default="lipsește"):
    """Returnează valoarea unui singur antet HTTP pentru un URL dat."""
    try:
        r = requests.get(url, timeout=TIMEOUT)
        return r.headers.get(name, default)
    except requests.RequestException:
        return default

print("\n--- Exercițiul 29 ---")
server_header = get_header(BASE_URL, name="Server")
print("Antet Server (cu argumente cu nume):", server_header)


# Exercițiul 30. Antete de securitate
def security_headers(url):
    """Verifică prezența a cinci antete de securitate și returnează un dicționar {antet: True/False}."""
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    try:
        r = requests.get(url, timeout=TIMEOUT)
        sec_results = {}
        for h in headers_to_check:
            sec_results[h] = h in r.headers
        return sec_results
    except requests.RequestException:
        return {h: False for h in headers_to_check}

print("\n--- Exercițiul 30 ---")
sec_dict = security_headers(BASE_URL)
print("Antete de securitate:", sec_dict)


# Exercițiul 31. Funcții care apelează funcții
def score_headers(results):
    """Primește dicționarul de antete de securitate și returnează un scor sub formă de șir (ex: '3/5')."""
    total = len(results)
    passed = sum(1 for val in results.values() if val)
    return f"{passed}/{total}"

print("\n--- Exercițiul 31 ---")
score_result = score_headers(security_headers(BASE_URL))
print("Scor antete de securitate:", score_result)


# Exercițiul 32. Două funcții, o sarcină
def fetch_robots(base):
    """Returnează conținutul fișierului /robots.txt sau None dacă lipsește."""
    try:
        r = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        if r.status_code == 200:
            return r.text
        return None
    except requests.RequestException:
        return None

def disallowed_paths(robots_text):
    """Extrage și returnează o listă cu toate valorile Disallow dintr-un text robots.txt."""
    if robots_text is None:
        return []
    disallowed = []
    for line in robots_text.splitlines():
        line_clean = line.strip()
        if line_clean.lower().startswith("disallow:"):
            path_val = line_clean.split(":", 1)[1].strip()
            if path_val:
                disallowed.append(path_val)
    return disallowed

print("\n--- Exercițiul 32 ---")
robots_content = fetch_robots(BASE_URL)
disallowed_list = disallowed_paths(robots_content)
print("Căi interzise (Disallow) găsite în robots.txt:", disallowed_list)


# Exercițiul 33. Oricâte argumente
def response_times(*urls):
    """Măsoară timpul de răspuns pentru oricâte URL-uri primite și returnează un dicționar {url: secunde}."""
    times_dict = {}
    for u in urls:
        try:
            start = time.perf_counter()
            requests.get(u, timeout=TIMEOUT)
            elapsed = time.perf_counter() - start
            times_dict[u] = round(elapsed, 3)
        except requests.RequestException:
            times_dict[u] = None
        time.sleep(1)
    return times_dict

print("\n--- Exercițiul 33 ---")
times_result = response_times(BASE_URL, ECHO_URL)
print("Timpi de răspuns (*urls):", times_result)


# Exercițiul 34. Argumente cu nume colectate
def log(message, **details):
    """Afișează un mesaj urmat de detalii suplimentare transmise sub formă de argumente cu nume."""
    details_str = " | ".join(f"{k}={v}" for k, v in details.items())
    if details_str:
        print(f"{message} | {details_str}")
    else:
        print(message)

print("\n--- Exercițiul 34 ---")
log("verificat", url=BASE_URL, status=200)
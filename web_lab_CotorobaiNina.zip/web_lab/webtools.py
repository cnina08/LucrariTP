# Modulul webtools.py
import requests
import time
import urllib.parse
import socket
import ssl
from datetime import datetime

TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-Nina"}

def fetch(url):
    """Trimite o cerere GET folosind antetele implicite ale modulului."""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=TIMEOUT)

def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    try:
        response = requests.get(url, headers=DEFAULT_HEADERS, timeout=TIMEOUT)
        return response.status_code
    except requests.RequestException:
        return None

def get_title(html):
    """Primește un șir HTML și returnează titlul paginii curățat."""
    start_tag = "<title>"
    end_tag = "</title>"
    start_idx = html.find(start_tag)
    if start_idx != -1:
        start_pos = start_idx + len(start_tag)
        end_pos = html.find(end_tag, start_pos)
        if end_pos != -1:
            return html[start_pos:end_pos].strip()
    return "Fără titlu"

def security_headers(url):
    """Verifică prezența a cinci antete de securitate și returnează un dicționar {antet: True/False}."""
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    try:
        r = requests.get(url, headers=DEFAULT_HEADERS, timeout=TIMEOUT)
        sec_results = {}
        for h in headers_to_check:
            sec_results[h] = h in r.headers
        return sec_results
    except requests.RequestException:
        return {h: False for h in headers_to_check}

def score_headers(results):
    """Calculează scorul antetelor de securitate sub formă de text (ex: '3/5')."""
    total = len(results)
    passed = sum(1 for val in results.values() if val)
    return f"{passed}/{total}"

def resolve(hostname):
    """Returnează adresa IP pentru un hostname dat."""
    try:
        return socket.gethostbyname(hostname)
    except socket.gaierror:
        return "IP indisponibil"

def get_redirects(url):
    """Urmărește istoricul de redirecționări pornind de la un URL (ex: http)."""
    try:
        r = requests.get(url, headers=DEFAULT_HEADERS, timeout=TIMEOUT, allow_redirects=True)
        history_codes = [str(h.status_code) for h in r.history]
        return history_codes, r.url
    except requests.RequestException:
        return [], url

def cert_days_left(hostname):
    """Returnează numărul de zile rămase până la expirarea certificatului SSL."""
    try:
        context = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                not_after_str = cert["notAfter"]
                expiration_seconds = ssl.cert_time_to_seconds(not_after_str)
                current_seconds = datetime.now().timestamp()
                diff_seconds = expiration_seconds - current_seconds
                return int(diff_seconds // 86400)
    except Exception:
        return 0

def fetch_robots(base):
    """Returnează textul fișierului /robots.txt sau None."""
    try:
        r = requests.get(base + "/robots.txt", headers=DEFAULT_HEADERS, timeout=TIMEOUT)
        if r.status_code == 200:
            return r.text
        return None
    except requests.RequestException:
        return None

def disallowed_paths(robots_text):
    """Extrage căile interzise (Disallow) din textul robots.txt."""
    if robots_text is None:
        return []
    disallowed = []
    for line in robots_text.splitlines():
        line_clean = line.strip()
        if line_clean.lower().startswith("disallow:"):
            path_val = line_clean.split(":", 1)[1].strip()
            if path_val:
                disallowed.append(path_val)
    return disallowed

def split_links_count(html, domain):
    import re
    raw_links = re.findall(r'href="([^"]+)"', html)
    unique_links = list(dict.fromkeys(raw_links))
    internal = 0
    external = 0
    for link in unique_links:
        absolute_url = urllib.parse.urljoin(f"https://{domain}", link)
        parsed = urllib.parse.urlparse(absolute_url)
        if parsed.netloc == domain or parsed.netloc == "":
            internal += 1
        else:
            external += 1
    return internal, external

def check_paths(base, paths_list):
    """Verifică o listă de căi și returnează un dicționar {path: status_code}."""
    results = {}
    for path in paths_list:
        full_url = base + path
        try:
            r = requests.get(full_url, headers=DEFAULT_HEADERS, timeout=TIMEOUT)
            results[path] = r.status_code
        except requests.RequestException:
            results[path] = None
        time.sleep(1)
    return results

def site_report(url):
    """Generează raportul complet al site-ului și returnează datele ca dicționar."""
    parsed_netloc = urllib.parse.urlparse(url).netloc
    resp = fetch(url)
    
    status_code = resp.status_code
    title = get_title(resp.text)
    ip_addr = resolve(parsed_netloc)
    
    # Redirecționări de la HTTP simplu
    http_url = url.replace("https://", "http://")
    history_codes, final_url = get_redirects(http_url)
    
    sec_dict = security_headers(url)
    sec_score = score_headers(sec_dict)
    days_cert = cert_days_left(parsed_netloc)
    
    internal_c, external_c = split_links_count(resp.text, parsed_netloc)
    
    robots_txt = fetch_robots(url)
    disallowed = disallowed_paths(robots_txt)
    
    report_data = {
        "url": url,
        "status_code": status_code,
        "title": title,
        "ip_address": ip_addr,
        "redirects": history_codes,
        "security_score": sec_score,
        "cert_days_left": days_cert,
        "internal_links": internal_c,
        "external_links": external_c,
        "disallowed_paths": disallowed
    }
    return report_data

if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
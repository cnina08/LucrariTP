# Laborator: funcții, metode și importuri pe web - Partea 4
# Student: <Cotorobai Nina>

import requests
import time
import urllib.parse
import re
from html.parser import HTMLParser
import hashlib
import json
import socket
import ssl
from datetime import datetime

BASE_URL = "https://cybercor.org"
TIMEOUT = 10  # secunde

print("=== PARTEA 4: Alte module din biblioteca standard ===")

# Exercițiul 35. Descompunerea unui URL
print("\n--- Exercițiul 35 ---")
parsed_url = urllib.parse.urlparse("https://cybercor.org/path?x=1#top")
print("scheme:", parsed_url.scheme)
print("netloc:", parsed_url.netloc)
print("path:", parsed_url.path)
print("query:", parsed_url.query)
print("fragment:", parsed_url.fragment)


# Exercițiul 36. Compunerea URL-urilor
print("\n--- Exercițiul 36 ---")
relative_links = ["/about", "contact.html", "../index.html"]
for link in relative_links:
    full_resolved = urllib.parse.urljoin(BASE_URL, link)
    print(f"Relativ: {link} -> Complet: {full_resolved}")


# Exercițiul 37. Extragerea legăturilor
def extract_links(html):
    """Extrage toate legăturile (href) de pe pagină și returnează o listă fără duplicate."""
    raw_links = re.findall(r'href="([^"]+)"', html)
    # Eliminăm duplicatele păstrând ordinea folosind dict.fromkeys
    return list(dict.fromkeys(raw_links))

print("\n--- Exercițiul 37 ---")
try:
    resp_37 = requests.get(BASE_URL, timeout=TIMEOUT)
    unique_links = extract_links(resp_37.text)
    print(f"S-au găsit {len(unique_links)} legături unice.")
    print("Primele 5 legături:", unique_links[:5])
except requests.RequestException as e:
    print("Eroare la descărcare:", e)


# Exercițiul 38. Interne sau externe?
def split_links(links, domain):
    """Împarte legăturile în două liste: interne (același domeniu) și externe (alte site-uri)."""
    internal = []
    external = []
    for link in links:
        # Transformăm linkul relativ în absolut folosind urljoin
        absolute_url = urllib.parse.urljoin(f"https://{domain}", link)
        parsed = urllib.parse.urlparse(absolute_url)
        
        # Verificăm netloc-ul
        if parsed.netloc == domain or parsed.netloc == "":
            internal.append(link)
        else:
            external.append(link)
    return internal, external

print("\n--- Exercițiul 38 ---")
sample_links = ["/despre", "https://google.com/search", "contact.html", "https://cybercor.org/servicii"]
domain_name = urllib.parse.urlparse(BASE_URL).netloc
int_l, ext_l = split_links(sample_links, domain_name)
print("Legături interne:", int_l)
print("Legături externe:", ext_l)


# Exercițiul 39. Propriile metode (Parser HTML pentru imagini)
class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        images = []
        self.images = images
 
    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            attributes_dict = dict(attrs)
            src_val = attributes_dict.get("src")
            if src_val:
                self.images.append(src_val)

print("\n--- Exercițiul 39 ---")
# Test local cu HTML cunoscut
test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
finder = ImageFinder()
finder.feed(test_html)

assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul local a trecut cu succes!")

# Rulare pe site-ul real
try:
    resp_39 = requests.get(BASE_URL, timeout=TIMEOUT)
    finder_real = ImageFinder()
    finder_real.feed(resp_39.text)
    print(len(finder_real.images), "imagini găsite pe site-ul real.")
except requests.RequestException as e:
    print("Eroare la site-ul real:", e)


# Exercițiul 40. Amprenta paginii
def page_fingerprint(url):
    """Returnează amprenta SHA-256 a conținutului paginii."""
    r = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(r.content).hexdigest()

print("\n--- Exercițiul 40 ---")
fp1 = page_fingerprint(BASE_URL)
fp2 = page_fingerprint(BASE_URL)
print("Amprenta 1:", fp1)
print("Amprenta 2:", fp2)
print("Sunt identice?", fp1 == fp2)
# Răspuns: Amprentele ar fi diferite dacă conținutul paginii s-ar schimba între cele două cereri 
# (de exemplu, un articol nou, o știre sau un contor actualizat).


# Exercițiul 41. Salvarea în JSON
print("\n--- Exercițiul 41 ---")
try:
    resp_41 = requests.get(BASE_URL, timeout=TIMEOUT)
    # Salvăm antetele în headers.json
    with open("headers.json", "w", encoding="utf-8") as f:
        json.dump(dict(resp_41.headers), f, indent=2)
    
    # Încărcăm înapoi fișierul
    with open("headers.json", "r", encoding="utf-8") as f:
        loaded_headers = json.load(f)
    print("Antet 'Content-Type' încărcat din fișierul JSON:", loaded_headers.get("Content-Type", "lipsă"))
except Exception as e:
    print("Eroare la lucrul cu fișierul JSON:", e)


# Exercițiul 42. Interogare DNS
def resolve(hostname):
    """Returnează adresa IP pentru un hostname dat."""
    return socket.gethostbyname(hostname)

print("\n--- Exercițiul 42 ---")
netloc_host = urllib.parse.urlparse(BASE_URL).netloc
ip_address = resolve(netloc_host)
print(f"Adresa IP pentru {netloc_host}:", ip_address)


# Exercițiul 43. Expirarea certificatului
def cert_days_left(hostname):
    """Returnează numărul de zile rămase până la expirarea certificatului SSL al unui host."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            not_after_str = cert["notAfter"]
            # Convertim data certificatului în secunde
            expiration_seconds = ssl.cert_time_to_seconds(not_after_str)
            current_seconds = datetime.now().timestamp()
            diff_seconds = expiration_seconds - current_seconds
            days_left = int(diff_seconds // 86400)  # 86400 secunde într-o zi
            return days_left

print("\n--- Exercițiul 43 ---")
try:
    days = cert_days_left(netloc_host)
    print(f"Zile rămase până la expirarea certificatului SSL pentru {netloc_host}:", days)
except Exception as e:
    print("Eroare la citirea certificatului SSL:", e)